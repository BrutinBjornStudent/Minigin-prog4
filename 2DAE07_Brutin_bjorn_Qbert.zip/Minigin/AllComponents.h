#pragma once
#include "Component.h"
#include "RenderComponent.h"
#include "TextComponent.h"