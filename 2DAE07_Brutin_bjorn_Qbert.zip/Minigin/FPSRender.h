#pragma once

#include "FPS.h"
#include "GameObject.h"
//#include "TextObject.h"
//#include "Font.h"
//
//class FPSRender :
//    public dae::SceneObject
//{
//public:
//    FPSRender(std::shared_ptr<dae::TextObject>& textbox);
//    ~FPSRender();
//
//    std::shared_ptr<dae::TextObject>& GetTextObj() { return m_text; };
//
//    FPSRender(const FPSRender& other) = delete;
//    FPSRender(FPSRender&&) noexcept = delete;
//    FPSRender& operator=(const FPSRender&) = delete;
//    FPSRender& operator=(FPSRender&&) noexcept = delete;
//
//    void Update(float deltatime) override;
//    void Render() const override;
//private:
//    std::shared_ptr<dae::TextObject> m_text;
//    std::shared_ptr<dae::Font> m_font;
//    float m_time;
//  
//};

