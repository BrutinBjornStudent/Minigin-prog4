#pragma once


enum class Event
{
	
	nothing_Happens = 0,
	player_Died = 1,
	tile_color_change = 2,
	defeat_coily = 3,
	disc_remains = 4,
	catching_slick_or_slam = 5
};

